package com.semihbeceren.scrabble.constant;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class AppConstants {
    public static final Map<Character, Integer> LETTER_AWARDS;
    public static final int BOARD_SIZE = 15;

    static {
        Map<Character, Integer> awards = new HashMap<>(29);

        awards.put('A', 1);
        awards.put('B', 3);
        awards.put('C', 4);
        awards.put('D', 3);
        awards.put('E', 1);
        awards.put('F', 7);
        awards.put('G', 5);
        awards.put('Ğ', 8);
        awards.put('H', 5);
        awards.put('I', 2);
        awards.put('İ', 1);
        awards.put('J', 10);
        awards.put('K', 1);
        awards.put('L', 1);
        awards.put('M', 2);
        awards.put('N', 1);
        awards.put('O', 2);
        awards.put('Ö', 7);
        awards.put('P', 5);
        awards.put('R', 1);
        awards.put('S', 2);
        awards.put('Ş', 4);
        awards.put('T', 1);
        awards.put('U', 2);
        awards.put('Ü', 3);
        awards.put('V', 7);
        awards.put('Y', 3);
        awards.put('Z', 4);

        LETTER_AWARDS = Collections.unmodifiableMap(awards);
    }
}
