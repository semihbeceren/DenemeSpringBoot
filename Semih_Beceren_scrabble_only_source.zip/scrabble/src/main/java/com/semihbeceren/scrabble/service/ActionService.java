package com.semihbeceren.scrabble.service;

import com.semihbeceren.scrabble.constant.AppConstants;
import com.semihbeceren.scrabble.entity.Action;
import com.semihbeceren.scrabble.entity.Board;
import com.semihbeceren.scrabble.entity.Letter;
import com.semihbeceren.scrabble.exception.ActionNotValidException;
import com.semihbeceren.scrabble.model.ActionResult;
import com.semihbeceren.scrabble.model.Coordinate;
import com.semihbeceren.scrabble.model.Move;
import com.semihbeceren.scrabble.model.Orientation;
import com.semihbeceren.scrabble.repository.ActionRepository;
import com.semihbeceren.scrabble.repository.LetterRepository;
import com.semihbeceren.scrabble.util.WordProcessUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ActionService {

    private final BoardService boardService;
    private final DictionaryService dictionaryService;
    private final ActionRepository actionRepository;
    private final LetterRepository letterRepository;

    @Autowired
    public ActionService(BoardService boardService, DictionaryService dictionaryService, ActionRepository actionRepository, LetterRepository letterRepository) {
        this.boardService = boardService;
        this.dictionaryService = dictionaryService;
        this.actionRepository = actionRepository;
        this.letterRepository = letterRepository;
    }

    public List<ActionResult> takeActions(Long boardId, List<Move> moves) {
        validateBoardStatus(boardId);
        validateMoveActions(boardId, moves);

        int sequence = getNextSequence(boardId);

        List<Action> actions = moves.stream()
                .map(move -> new Action(sequence, new Board(boardId), move.getWord(), move.getCoordinate(), move.getOrientation()))
                .collect(Collectors.toList());

        List<Action> savedActions = actionRepository.saveBulk(actions);

        return savedActions.stream()
                .map(this::mapActionToActionResult)
                .collect(Collectors.toList());
    }

    public List<ActionResult> findActionHistoriesByBoardId(Long boardId) {
        validateBoardStatus(boardId);

        return actionRepository.findActionsByBoardIdOrderByCreatedAtAsc(boardId).stream()
                .map(this::mapActionToActionResult)
                .collect(Collectors.toList());
    }

    public List<ActionResult> findActionHistoriesByBoardIdAndSequence(Long boardId, Integer sequence) {
        validateBoardStatus(boardId);

        return actionRepository.findActionsByBoardIdAndSequenceOrderByCreatedAtAsc(boardId, sequence).stream()
                .map(this::mapActionToActionResult)
                .collect(Collectors.toList());
    }

    private int getNextSequence(Long boardId) {
        return actionRepository.findMaxSequenceByBoardId(boardId) + 1;
    }

    private void validateBoardStatus(Long boardId) throws EntityNotFoundException {
        if(!boardService.isBoardActive(boardId))
            throw new EntityNotFoundException("Board is not active!");
    }

    private void validateMoveActions(Long boardId, List<Move> moves) throws ActionNotValidException {
        if(!isWordsValid(moves.stream().map(Move::getWord).collect(Collectors.toList())))
            throw new ActionNotValidException("Some words does not contains on dictionary!");

        if(!isNewWordsUnique(moves.stream().map(Move::getWord).collect(Collectors.toList())))
            throw new ActionNotValidException("Some words duplicated as you want to play!");

        if(!isWordsUniqueOnBoard(moves.stream().map(Move::getWord).collect(Collectors.toList()), findActionHistoriesByBoardId(boardId).stream().map(actionResult -> actionResult.getMove().getWord()).collect(Collectors.toList())))
            throw new ActionNotValidException("Some words duplicated on board!");

        List<List<Letter>> newLetters = WordProcessUtil.wordToLetter(new Action(boardId), moves);

        if(!isLetterPositionsValid(newLetters))
            throw new ActionNotValidException("Letter positions are ambiguous!");

        List<Letter> lettersOnBoard = letterRepository.findLettersByBoardId(boardId);

        if(!isLetterRelativePositionsValid(newLetters, lettersOnBoard))
            throw new ActionNotValidException("Relative letter positions are ambiguous!");

    }

    private boolean isWordsValid(List<String> words) {
        return words.stream().allMatch(dictionaryService::isWordValid);
    }

    private boolean isLetterPositionsValid(List<List<Letter>> lettersList) {
        List<Letter> letters = new ArrayList<>();
        lettersList.forEach(letters::addAll);
        return letters.stream().allMatch(letter -> letter.getX() > 0 && letter.getX() <= AppConstants.BOARD_SIZE && letter.getY() > 0 && letter.getY() <= AppConstants.BOARD_SIZE);
    }

    private boolean isLetterRelativePositionsValid(List<List<Letter>> newLettersList, List<Letter> lettersOnBoard) {
        Set<Letter> lettersOnBoardSet = new HashSet<>(lettersOnBoard);

        for (List<Letter> letters : newLettersList) {
            if(lettersOnBoardSet.isEmpty()) {
                lettersOnBoardSet.addAll(letters);
            } else {
                if(lettersOnBoardSet.stream().noneMatch(letter -> letter.equals(letters.get(0)))) {
                    return false;
                }

                long exactMatchCount = letters.stream()
                        .filter(lettersOnBoardSet::contains)
                        .count();

                long coordinatesMatchCount = letters.stream()
                        .filter(letter -> lettersOnBoardSet.stream()
                                .anyMatch(letterOnBoard -> letterOnBoard.getX().equals(letter.getX()) && letterOnBoard.getY().equals(letter.getY())))
                        .count();

                if(exactMatchCount != coordinatesMatchCount) {
                    return false;
                }

                lettersOnBoardSet.addAll(letters);
            }
        }

        return true;
    }

    private boolean isNewWordsUnique(List<String> words) {
        return new HashSet<>(words).size() == words.size();
    }

    private boolean isWordsUniqueOnBoard(List<String> words, List<String> wordsOnBoard) {
        return wordsOnBoard.stream().noneMatch(words::contains);
    }

    private ActionResult mapActionToActionResult(Action action) {
        Letter firstLetter = action.getLetters().get(0);

        return new ActionResult(action.getBoard().getId(),
                new Move(new Coordinate(firstLetter.getX(), firstLetter.getY()), action.isVertical() ? Orientation.VERTICAL : Orientation.HORIZONTAL, action.getWord()),
                action.getAward(),
                action.getSequence());
    }

}
