package com.semihbeceren.scrabble.entity;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.semihbeceren.scrabble.model.Status;

import javax.persistence.Entity;
import javax.persistence.Transient;

@Entity
public class Board extends BaseEntity {

    @JsonProperty("status")
    private boolean active;

    public Board() {
    }

    public Board(Long id) {
        this.setId(id);
        this.active = true;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Transient
    @JsonGetter("status")
    public Status getActivationStatus() {
        return Status.ofValue(this.active);
    }

    @Transient
    @JsonSetter("status")
    public void setActivationStatus(Status active) {
        this.active = active.getValue();
    }
}
