package com.semihbeceren.scrabble.service;

import com.semihbeceren.scrabble.BaseTest;
import com.semihbeceren.scrabble.entity.Action;
import com.semihbeceren.scrabble.entity.Board;
import com.semihbeceren.scrabble.model.ActionResult;
import com.semihbeceren.scrabble.model.Coordinate;
import com.semihbeceren.scrabble.model.Move;
import com.semihbeceren.scrabble.model.Orientation;
import com.semihbeceren.scrabble.repository.ActionRepository;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;
import static org.hamcrest.Matchers.*;

public class ActionServiceTest extends BaseTest {

    @Autowired
    private ActionService actionService;

    @Autowired
    private BoardService boardService;

    @Autowired
    private ActionRepository actionRepository;

    private Board board;

    @Before
    public void initialize() {
        board = boardService.createBoard();
    }

    @Test
    public void testTakeActions() {
        List<Move> moves = new ArrayList<>();
        moves.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEME"));
        moves.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEMEM"));
        moves.add(new Move(new Coordinate(2,1), Orientation.VERTICAL, "ESNEMEK"));
        List<ActionResult> actionResults = actionService.takeActions(board.getId(), moves);
        assertThat(actionResults.size(), equalTo(3));
    }

    @Test
    public void testFindActionHistoriesByBoardId() {
        int nextSeq = actionRepository.findMaxSequenceByBoardId(board.getId()) + 1;

        Action action = new Action(nextSeq, board, "TEST", new Coordinate(1, 1), Orientation.HORIZONTAL);
        Action action2 = new Action(nextSeq, board, "CASE", new Coordinate(1, 2), Orientation.HORIZONTAL);
        actionRepository.saveBulk(Arrays.asList(action, action2));

        List<Action> foundedActions = actionRepository.findActionsByBoardIdOrderByCreatedAtAsc(board.getId());

        assertThat(foundedActions.size(), equalTo(2));
        assertThat(foundedActions.get(0).getWord(), equalTo("TEST"));
    }

    @Test
    public void testFindActionHistoriesByBoardIdAndSequence() {
        Action action = new Action(actionRepository.findMaxSequenceByBoardId(board.getId()) + 1, board, "TEST", new Coordinate(1, 1), Orientation.HORIZONTAL);
        actionRepository.save(action);
        Action action2 = new Action(actionRepository.findMaxSequenceByBoardId(board.getId()) + 1, board, "CASE", new Coordinate(1, 2), Orientation.HORIZONTAL);
        actionRepository.save(action2);

        List<Action> foundedActions = actionRepository.findActionsByBoardIdAndSequenceOrderByCreatedAtAsc(board.getId(), 1);

        assertThat(foundedActions.size(), equalTo(1));
        assertThat(foundedActions.get(0).getWord(), equalTo("TEST"));
    }
}
