package com.semihbeceren.scrabble.repository.impl;

import com.semihbeceren.scrabble.entity.Board;
import com.semihbeceren.scrabble.repository.BoardRepository;
import org.springframework.stereotype.Repository;

@Repository("boardRepository")
public class BoardRepositoryImpl extends BaseRepositoryImpl<Board> implements BoardRepository {
}
