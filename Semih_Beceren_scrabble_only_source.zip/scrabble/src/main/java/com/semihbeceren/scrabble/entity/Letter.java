package com.semihbeceren.scrabble.entity;

import javax.persistence.*;
import java.util.Calendar;
import java.util.Objects;

@Entity
@NamedQueries({
        @NamedQuery(name = "findLettersByBoardId", query = "Select letter from Letter letter where letter.action.board.id = :boardId"),
})
public class Letter extends BaseEntity{

    @Column(nullable = false)
    private Integer x;

    @Column(nullable = false)
    private Integer y;

    private String letter;

    public Letter() {
    }

    public Letter(Integer x, Integer y, String letter, Action action) {
        this.x = x;
        this.y = y;
        this.letter = letter;
        this.action = action;
        this.setCreatedAt(Calendar.getInstance().getTime());
    }

    @JoinColumn(name = "action_id", referencedColumnName = "id", foreignKey = @ForeignKey(name = "FK_LETTER_ACTION"))
    @ManyToOne
    private Action action;

    public Integer getX() {
        return x;
    }

    public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return y;
    }

    public void setY(Integer y) {
        this.y = y;
    }

    public String getLetter() {
        return letter;
    }

    public void setLetter(String letter) {
        this.letter = letter;
    }

    public Action getAction() {
        return action;
    }

    public void setAction(Action action) {
        this.action = action;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Letter letter1 = (Letter) o;
        return x.equals(letter1.x) &&
                y.equals(letter1.y) &&
                letter.equals(letter1.letter);
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y, letter);
    }
}
