package com.semihbeceren.scrabble.service;

import com.semihbeceren.scrabble.entity.Board;
import com.semihbeceren.scrabble.exception.WrongOperationException;
import com.semihbeceren.scrabble.model.Status;
import com.semihbeceren.scrabble.repository.BoardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;

@Service
public class BoardService {

    private final BoardRepository boardRepository;

    @Autowired
    public BoardService(BoardRepository boardRepository) {
        this.boardRepository = boardRepository;
    }

    public Board createBoard() {
        Board board =  new Board();
        board.setActive(Boolean.TRUE);
        return boardRepository.save(board);
    }

    public Board setStatus(Long boardId, Status status) {
        if(Status.ACTIVE.equals(status)) {
            throw new WrongOperationException("You are trying to set board's status ACTIVE. This operation not permitted!");
        }

        Board foundedBoard = boardRepository.findById(boardId).orElseThrow(EntityNotFoundException::new);
        foundedBoard.setActivationStatus(status);
        return boardRepository.save(foundedBoard);
    }

    public boolean isBoardActive(Long boardId) {
        return Status.ACTIVE.equals(boardRepository.findById(boardId).orElseThrow(EntityNotFoundException::new).getActivationStatus());
    }
}
