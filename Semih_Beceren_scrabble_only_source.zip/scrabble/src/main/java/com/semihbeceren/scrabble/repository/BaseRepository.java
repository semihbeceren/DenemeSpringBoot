package com.semihbeceren.scrabble.repository;

import com.semihbeceren.scrabble.entity.BaseEntity;

import java.util.List;
import java.util.Optional;

public interface BaseRepository <T extends BaseEntity> {
    Optional<T> findById(Long id);
    T save(T entity);
    List<T> saveBulk(List<T> entity);
}
