package com.semihbeceren.scrabble.exception;

public class ActionNotValidException extends RuntimeException {
    public ActionNotValidException(String message) {
        super(message);
    }
}
