package com.semihbeceren.scrabble.controller.v1;

import com.semihbeceren.scrabble.entity.Board;
import com.semihbeceren.scrabble.model.Move;
import com.semihbeceren.scrabble.model.Status;
import com.semihbeceren.scrabble.model.ActionResult;
import com.semihbeceren.scrabble.service.ActionService;
import com.semihbeceren.scrabble.service.BoardService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/boards")
@Api(value = "boards-controller")
public class BoardsController {

    private final BoardService boardService;
    private final ActionService actionService;

    @Autowired
    public BoardsController(BoardService boardService, ActionService actionService) {
        this.boardService = boardService;
        this.actionService = actionService;
    }

    @ApiOperation("Create a Scrabble Game Board and returns created board unique id.")
    @PostMapping("/")
    public ResponseEntity<Long> createBoard() {
        return ResponseEntity.ok(boardService.createBoard().getId());
    }

    @ApiOperation("Get board information with actions for a specified board and sequence.")
    @GetMapping("/{boardId}/sequences/{sequence}")
    public ResponseEntity<List<ActionResult>> getBoardContent(@PathVariable Long boardId, @PathVariable Integer sequence) {
        return ResponseEntity.ok(actionService.findActionHistoriesByBoardIdAndSequence(boardId, sequence));
    }

    @ApiOperation("Set status of a specified board.")
    @PutMapping("/{boardId}")
    public ResponseEntity<Board> setStatus(@PathVariable Long boardId, @RequestBody Status status) {
        return ResponseEntity.ok(boardService.setStatus(boardId, status));
    }

    @ApiOperation("Get all words on a specified board.")
    @GetMapping("/{boardId}/words")
    public ResponseEntity<List<ActionResult>> getWords(@PathVariable Long boardId) {
        return ResponseEntity.ok(actionService.findActionHistoriesByBoardId(boardId));
    }

    @ApiOperation("Take action on a specified board.")
    @PostMapping("/{boardId}")
    public ResponseEntity<List<ActionResult>> play(@PathVariable Long boardId, @RequestBody List<Move> moves) {
        return ResponseEntity.ok(actionService.takeActions(boardId, moves));
    }
}
