package com.semihbeceren.scrabble.repository;

import com.semihbeceren.scrabble.entity.Action;

import java.util.List;

public interface ActionRepository extends BaseRepository<Action> {
    List<Action> findActionsByBoardIdOrderByCreatedAtAsc(Long boardId);
    List<Action> findActionsByBoardIdAndSequenceOrderByCreatedAtAsc(Long boardId, Integer sequence);
    Integer findMaxSequenceByBoardId(Long boardId);
}
