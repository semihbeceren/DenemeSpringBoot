package com.semihbeceren.scrabble.repository;

import com.semihbeceren.scrabble.entity.Letter;

import java.util.List;

public interface LetterRepository extends BaseRepository<Letter> {
    List<Letter> findLettersByBoardId(Long boardId);
}
