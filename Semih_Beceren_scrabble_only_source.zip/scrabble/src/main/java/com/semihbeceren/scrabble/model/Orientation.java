package com.semihbeceren.scrabble.model;

public enum  Orientation {
    VERTICAL, HORIZONTAL
}
