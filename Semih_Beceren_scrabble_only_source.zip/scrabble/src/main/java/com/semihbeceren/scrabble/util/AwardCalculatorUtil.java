package com.semihbeceren.scrabble.util;

import com.semihbeceren.scrabble.constant.AppConstants;
import org.springframework.util.StringUtils;

import java.util.Locale;

public class AwardCalculatorUtil {

    public static Integer calculateAward(String word) {
        if(StringUtils.isEmpty(word))
            return 0;

        return word.toUpperCase(new Locale("tr", "TR")).chars()
                .map(c -> AppConstants.LETTER_AWARDS.get((char)c) == null ? 0 : AppConstants.LETTER_AWARDS.get((char)c))
                .reduce(0, Integer::sum);
    }

}
