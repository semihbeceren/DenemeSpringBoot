package com.semihbeceren.scrabble.service;

import com.semihbeceren.scrabble.BaseTest;
import com.semihbeceren.scrabble.entity.Board;
import com.semihbeceren.scrabble.exception.WrongOperationException;
import com.semihbeceren.scrabble.model.Status;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.Assert.*;
import static org.hamcrest.Matchers.*;

public class BoardServiceTest extends BaseTest {

    @Autowired
    private BoardService boardService;

    @Test
    public void testCreateBoard() {
        Board board = boardService.createBoard();
        assertNotNull(board);
        assertThat(board.getId(), is(greaterThan(0L)));
        assertThat(board.getActivationStatus(), equalTo(Status.ACTIVE));
    }

    @Test
    public void testSetStatus() {
        Board board = boardService.createBoard();
        assertThat(boardService.setStatus(board.getId(), Status.PASSIVE).getActivationStatus(), equalTo(Status.PASSIVE));
    }

    @Test
    public void testPassiveBoardNotActivatedAgain() {
        Board board = boardService.createBoard();
        boardService.setStatus(board.getId(), Status.PASSIVE);
        try {
            assertThat(boardService.setStatus(board.getId(), Status.ACTIVE).getActivationStatus(), equalTo(Status.PASSIVE));
        } catch (Exception e) {
            assertThat(e, instanceOf(WrongOperationException.class));
            assertThat(e.getMessage(), containsString("You are trying to set board's status ACTIVE"));
        }
    }

    @Test
    public void testIsBoardActive() {
        Board board = boardService.createBoard();
        assertTrue(boardService.isBoardActive(board.getId()));
        boardService.setStatus(board.getId(), Status.PASSIVE);
        assertFalse(boardService.isBoardActive(board.getId()));
    }

}
