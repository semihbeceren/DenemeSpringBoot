package com.semihbeceren.scrabble.repository;

import com.semihbeceren.scrabble.entity.Board;

public interface BoardRepository extends BaseRepository<Board> {
}
