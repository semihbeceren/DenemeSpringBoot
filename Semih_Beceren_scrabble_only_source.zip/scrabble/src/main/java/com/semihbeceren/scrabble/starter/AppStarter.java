package com.semihbeceren.scrabble.starter;


import com.semihbeceren.scrabble.config.AppConfig;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

import java.util.regex.Pattern;

public class AppStarter {

    private final static Logger LOGGER = LoggerFactory.getLogger(AppStarter.class);

    private static final String CONTEXT_PATH = "/";
    private static final String MAPPING_URL = "/";
    private static final int DEFAULT_PORT = 8080;

    public static void main(String[] args) throws Exception {
        int port = DEFAULT_PORT;

        if(args.length > 0) {
            String[] splitted = args[0].split(Pattern.quote("="));
            if(splitted.length == 2 && "port".equals(splitted[0])) {
                port = Integer.parseInt(splitted[1]);
            }
        }

        LOGGER.debug("Starting Jetty Server at port {}", port);
        Server server = new Server(port);
        server.setHandler(getServletContextHandler());
        server.start();
        LOGGER.info("Jetty Server started at port {}", port);
        server.join();
    }

    private static ServletContextHandler getServletContextHandler() {
        ServletContextHandler contextHandler = new ServletContextHandler(ServletContextHandler.NO_SESSIONS);
        contextHandler.setContextPath(CONTEXT_PATH);

        AnnotationConfigWebApplicationContext webAppContext = new AnnotationConfigWebApplicationContext();
        webAppContext.register(AppConfig.class);
        DispatcherServlet dispatcherServlet = new DispatcherServlet(webAppContext);
        ServletHolder springServletHolder = new ServletHolder("mvc-dispatcher", dispatcherServlet);
        contextHandler.addServlet(springServletHolder, MAPPING_URL);
        contextHandler.addEventListener(new ContextLoaderListener(webAppContext));

        return contextHandler;
    }

}
