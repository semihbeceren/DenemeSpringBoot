package com.semihbeceren.scrabble.repository.impl;

import com.semihbeceren.scrabble.entity.Letter;
import com.semihbeceren.scrabble.repository.LetterRepository;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;

@Repository("letterRepository")
public class LetterRepositoryImpl extends BaseRepositoryImpl<Letter> implements LetterRepository {
    @Override
    public List<Letter> findLettersByBoardId(Long boardId) {
        return getResultList("findLettersByBoardId", Collections.singletonList("boardId"), boardId);
    }
}
