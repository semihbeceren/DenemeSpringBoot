package com.semihbeceren.scrabble.logging;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class EndpointAspectLogger {

    private static final Logger LOGGER = LoggerFactory.getLogger(EndpointAspectLogger.class);
    private static final ObjectMapper OBJECT_MAPPER;

    static {
        OBJECT_MAPPER = new ObjectMapper();
        OBJECT_MAPPER.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        OBJECT_MAPPER.enable(SerializationFeature.INDENT_OUTPUT);
    }

    @Pointcut("execution(* com.semihbeceren.scrabble.controller..*(..))")
    public void whenExecuteControllerMethods() {}

    @Around("whenExecuteControllerMethods()")
    public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable{
        long start = System.currentTimeMillis();
        String className = joinPoint.getSignature().getDeclaringTypeName();
        String methodName = joinPoint.getSignature().getName();
        Object proceeded = joinPoint.proceed();
        long elapsedTime = System.currentTimeMillis() - start;
        LOGGER.info("{}.{} executed -> execution time : {} ms \n requestArgs: {}, \n response: {}", className, methodName, elapsedTime, OBJECT_MAPPER.writeValueAsString(joinPoint.getArgs()), OBJECT_MAPPER.writeValueAsString(proceeded));
        return proceeded;
    }

}
