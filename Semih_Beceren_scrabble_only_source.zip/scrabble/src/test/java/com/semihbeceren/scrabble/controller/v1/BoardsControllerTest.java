package com.semihbeceren.scrabble.controller.v1;

import com.semihbeceren.scrabble.BaseTest;
import com.semihbeceren.scrabble.entity.Board;
import com.semihbeceren.scrabble.exception.ActionNotValidException;
import com.semihbeceren.scrabble.exception.WrongOperationException;
import com.semihbeceren.scrabble.model.*;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.persistence.EntityNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.Assert.*;
import static org.hamcrest.Matchers.*;

public class BoardsControllerTest extends BaseTest {
    @Autowired
    private BoardsController boardsController;

    private Long boardId;

    @Before
    public void initialize() {
        boardId = boardsController.createBoard().getBody();
    }

    @Test
    public void testCreateBoard() {
        assertThat(boardsController.createBoard().getStatusCode(), equalTo(HttpStatus.OK));
        assertThat(boardsController.createBoard().getStatusCode(), equalTo(HttpStatus.OK));
        assertThat(boardsController.createBoard().getBody(), is(greaterThan(0L)));
    }

    @Test
    public void playGameSuccessfully() {
        List<Move> moves = new ArrayList<>();
        moves.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEME"));
        moves.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEMEM"));
        moves.add(new Move(new Coordinate(2,1), Orientation.VERTICAL, "ESNEMEK"));
        List<ActionResult> actionResults = boardsController.play(boardId, moves).getBody();
        assertNotNull(actionResults);
        assertThat(actionResults.size(), equalTo(3));
    }

    @Test
    public void playGameSuccessfullyOnDifferentBoards() {
        List<Move> moves = new ArrayList<>();
        moves.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEME"));
        moves.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEMEM"));
        moves.add(new Move(new Coordinate(2,1), Orientation.VERTICAL, "ESNEMEK"));
        List<ActionResult> actionResults = boardsController.play(boardsController.createBoard().getBody(), moves).getBody();

        assertNotNull(actionResults);
        assertThat(actionResults.size(), equalTo(3));

        List<Move> moves2 = new ArrayList<>();
        moves2.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEME"));
        moves2.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEMEM"));
        moves2.add(new Move(new Coordinate(2,1), Orientation.VERTICAL, "ESNEMEK"));
        List<ActionResult> actionResults2 = boardsController.play(boardsController.createBoard().getBody(), moves2).getBody();

        assertNotNull(actionResults2);
        assertThat(actionResults2.size(), equalTo(3));
    }

    @Test
    public void testGetBoardContent() {
        List<Move> moves = new ArrayList<>();
        moves.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEME"));
        moves.add(new Move(new Coordinate(2,1), Orientation.VERTICAL, "ESNEMEK"));
        boardsController.play(boardId, moves);

        ResponseEntity<List<ActionResult>> responseSequence1 = boardsController.getBoardContent(boardId, 1);

        assertThat(responseSequence1.getStatusCode(), equalTo(HttpStatus.OK));
        assertNotNull(responseSequence1.getBody());
        assertThat(responseSequence1.getBody().size(), equalTo(2));
        assertThat(responseSequence1.getBody().get(0).getSequence(), equalTo(1));
        assertThat(responseSequence1.getBody().get(0).getMove().getWord(), equalTo("DENEME"));
        assertThat(responseSequence1.getBody().get(1).getMove().getWord(), equalTo("ESNEMEK"));

        List<Move> moves2 = new ArrayList<>();
        moves2.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEMEM"));
        boardsController.play(boardId, moves2);

        ResponseEntity<List<ActionResult>> responseSequence2 = boardsController.getBoardContent(boardId, 2);

        assertThat(responseSequence2.getStatusCode(), equalTo(HttpStatus.OK));
        assertNotNull(responseSequence2.getBody());
        assertThat(responseSequence2.getBody().size(), equalTo(1));
        assertThat(responseSequence2.getBody().get(0).getSequence(), equalTo(2));
        assertThat(responseSequence2.getBody().get(0).getMove().getWord(), equalTo("DENEMEM"));
    }

    @Test
    public void setStatusPassive() {
        ResponseEntity<Board> response = boardsController.setStatus(boardId, Status.PASSIVE);
        assertThat(response.getStatusCode(), equalTo(HttpStatus.OK));
        assertNotNull(response.getBody());
        assertThat(response.getBody().getActivationStatus(), equalTo(Status.PASSIVE));
    }

    @Test
    public void canNotSetStatusActiveForPassiveStatus() {
        ResponseEntity<Board> response = boardsController.setStatus(boardId, Status.PASSIVE);
        assertThat(response.getStatusCode(), equalTo(HttpStatus.OK));
        assertNotNull(response.getBody());
        assertThat(response.getBody().getActivationStatus(), equalTo(Status.PASSIVE));

        try {
            boardsController.setStatus(boardId, Status.ACTIVE);
        } catch (Exception e) {
            assertThat(e, instanceOf(WrongOperationException.class));
            assertThat(e.getMessage(), containsString("You are trying to set board's status ACTIVE"));
        }
    }

    @Test
    public void getAllWordsOnBoard() {
        List<Move> moves = new ArrayList<>();
        moves.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEME"));
        moves.add(new Move(new Coordinate(2,1), Orientation.VERTICAL, "ESNEMEK"));
        boardsController.play(boardId, moves);

        List<Move> moves2 = new ArrayList<>();
        moves2.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEMEM"));
        boardsController.play(boardId, moves2);

        ResponseEntity<List<ActionResult>> response = boardsController.getWords(boardId);

        assertThat(response.getStatusCode(), equalTo(HttpStatus.OK));
        assertNotNull(response.getBody());
        assertThat(response.getBody().size(), equalTo(3));
        assertThat(response.getBody().stream().map(actionResult -> actionResult.getMove().getWord()).collect(Collectors.toList()), contains("DENEME", "ESNEMEK", "DENEMEM"));
    }

    @Test
    public void giveAnErrorWithPlayWhenBoardStatusPassive() {
        boardsController.play(boardId, Collections.singletonList(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEME")));
        boardsController.setStatus(boardId, Status.PASSIVE);

        try {
            assertThat(boardsController.play(boardId, Collections.singletonList(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEMEM"))), equalTo(HttpStatus.INTERNAL_SERVER_ERROR));
        } catch (Exception e) {
            assertThat(e, instanceOf(EntityNotFoundException.class));
            assertThat(e.getMessage(), containsString("Board is not active!"));
        }
    }

    @Test
    public void giveAnErrorWithPlayWhenWordsNotContainedOnDictionary() {
        try {
            assertThat(boardsController.play(boardId, Collections.singletonList(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "ABC"))), equalTo(HttpStatus.INTERNAL_SERVER_ERROR));
        } catch (Exception e) {
            assertThat(e, instanceOf(ActionNotValidException.class));
            assertThat(e.getMessage(), containsString("Some words does not contains on dictionary!"));
        }
    }

    @Test
    public void giveAnErrorWithPlayWhenWordsAsInputDuplicated() {
        try {
            List<Move> moves = new ArrayList<>();
            moves.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEME"));
            moves.add(new Move(new Coordinate(1,1), Orientation.VERTICAL, "DENEME"));
            assertThat(boardsController.play(boardId, moves).getStatusCode(), equalTo(HttpStatus.INTERNAL_SERVER_ERROR));
        } catch (Exception e) {
            assertThat(e, instanceOf(ActionNotValidException.class));
            assertThat(e.getMessage(), containsString("Some words duplicated as you want to play!"));
        }
    }

    @Test
    public void giveAnErrorWithPlayWhenWordsAsOnBoardDuplicated() {
        try {
            List<Move> moves = new ArrayList<>();
            moves.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEME"));
            moves.add(new Move(new Coordinate(2,1), Orientation.VERTICAL, "ESNEMEK"));
            boardsController.play(boardId, moves);

            List<Move> moves2 = new ArrayList<>();
            moves2.add(new Move(new Coordinate(1,1), Orientation.VERTICAL, "DENEME"));
            assertThat(boardsController.play(boardId, moves2).getStatusCode(), equalTo(HttpStatus.INTERNAL_SERVER_ERROR));
        } catch (Exception e) {
            assertThat(e, instanceOf(ActionNotValidException.class));
            assertThat(e.getMessage(), containsString("Some words duplicated on board!"));
        }
    }

    @Test
    public void giveAnErrorWithPlayWhenLetterAsInputPositionsAreAmbiguous() {
        try {
            List<Move> moves = new ArrayList<>();
            moves.add(new Move(new Coordinate(15,1), Orientation.HORIZONTAL, "DENEME"));
            assertThat(boardsController.play(boardId, moves).getStatusCode(), equalTo(HttpStatus.INTERNAL_SERVER_ERROR));
        } catch (Exception e) {
            assertThat(e, instanceOf(ActionNotValidException.class));
            assertThat(e.getMessage(), containsString("Letter positions are ambiguous!"));
        }
    }

    @Test
    public void giveAnErrorWithPlayWhenRelativeLetterPositionsAreAmbiguous() {
        try {
            List<Move> moves = new ArrayList<>();
            moves.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEME"));
            moves.add(new Move(new Coordinate(1,2), Orientation.HORIZONTAL, "ESNEMEK"));
            assertThat(boardsController.play(boardId, moves).getStatusCode(), equalTo(HttpStatus.INTERNAL_SERVER_ERROR));
        } catch (Exception e) {
            assertThat(e, instanceOf(ActionNotValidException.class));
            assertThat(e.getMessage(), containsString("Relative letter positions are ambiguous!"));
        }

        try {
            List<Move> moves = new ArrayList<>();
            moves.add(new Move(new Coordinate(1,1), Orientation.HORIZONTAL, "DENEME"));
            moves.add(new Move(new Coordinate(2,1), Orientation.VERTICAL, "ESNEMEK"));
            moves.add(new Move(new Coordinate(4,1), Orientation.VERTICAL, "ENGEL"));
            moves.add(new Move(new Coordinate(2,2), Orientation.HORIZONTAL, "SEL"));
            assertThat(boardsController.play(boardId, moves).getStatusCode(), equalTo(HttpStatus.INTERNAL_SERVER_ERROR));
        } catch (Exception e) {
            assertThat(e, instanceOf(ActionNotValidException.class));
            assertThat(e.getMessage(), containsString("Relative letter positions are ambiguous!"));
        }
    }

}
