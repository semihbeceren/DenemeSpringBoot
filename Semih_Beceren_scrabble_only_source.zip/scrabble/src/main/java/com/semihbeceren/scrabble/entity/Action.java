package com.semihbeceren.scrabble.entity;

import com.semihbeceren.scrabble.model.Coordinate;
import com.semihbeceren.scrabble.model.Orientation;
import com.semihbeceren.scrabble.util.AwardCalculatorUtil;
import com.semihbeceren.scrabble.util.WordProcessUtil;

import javax.persistence.*;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Entity
@NamedQueries({
        @NamedQuery(name = "findActionsByBoardIdOrderByCreatedAtAsc", query = "Select action from Action action where action.board.id = :boardId order by action.createdAt asc"),
        @NamedQuery(name = "findActionsByBoardIdAndSequenceOrderByCreatedAtAsc", query = "Select action from Action action where action.board.id = :boardId and sequence = :sequence order by action.createdAt asc"),
        @NamedQuery(name = "findMaxSequenceByBoardId", query = "select max (action.sequence) from Action action where action.board.id = :boardId")
})
public class Action extends BaseEntity {

    @Column(nullable = false)
    private Integer award;

    @Column(nullable = false)
    private Integer sequence;

    @Column(nullable = false)
    private boolean vertical;

    @JoinColumn(name = "board_id", referencedColumnName = "id", foreignKey = @ForeignKey(name = "FK_ACTION_BOARD"))
    @ManyToOne
    private Board board;

    @OneToMany(mappedBy = "action", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Letter> letters;

    public Action() {
    }

    public Action(Long boardId) {
        this.setBoard(new Board(boardId));
    }

    public Action(Integer sequence, Board board, String word, Coordinate coordinate, Orientation orientation) {
        this.sequence = sequence;
        this.board = board;
        setWord(word, coordinate, orientation);
        this.award = AwardCalculatorUtil.calculateAward(word);
    }

    public Integer getAward() {
        return award;
    }

    public void setAward(Integer award) {
        this.award = award;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public boolean isVertical() {
        return vertical;
    }

    public void setVertical(boolean vertical) {
        this.vertical = vertical;
    }

    public Board getBoard() {
        return board;
    }

    public void setBoard(Board board) {
        this.board = board;
    }

    public List<Letter> getLetters() {
        if(this.vertical)
            return letters.stream().sorted(Comparator.comparingInt(Letter::getX)).collect(Collectors.toList());
        else
            return letters.stream().sorted(Comparator.comparingInt(Letter::getY)).collect(Collectors.toList());
    }

    public void setLetters(List<Letter> letters) {
        this.letters = letters;
    }

    @Transient
    public String getWord() {
        StringBuilder stringBuilder = new StringBuilder(this.letters.size());
        getLetters().forEach(letter -> stringBuilder.append(letter.getLetter()));
        return stringBuilder.toString();
    }

    @Transient
    public void setWord(String word, Coordinate coordinate, Orientation orientation) {
        this.letters = WordProcessUtil.wordToLetter(this, word, coordinate, orientation);
    }
}
