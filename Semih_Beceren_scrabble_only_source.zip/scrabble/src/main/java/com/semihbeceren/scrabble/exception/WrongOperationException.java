package com.semihbeceren.scrabble.exception;

public class WrongOperationException extends RuntimeException {
    public WrongOperationException(String exceptionDetail) {
        super(exceptionDetail);
    }
}
