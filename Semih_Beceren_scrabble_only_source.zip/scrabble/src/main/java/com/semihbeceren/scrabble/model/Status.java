package com.semihbeceren.scrabble.model;

import java.util.stream.Stream;

public enum  Status {
    ACTIVE(Boolean.TRUE),
    PASSIVE(Boolean.FALSE);

    private boolean value;

    Status(boolean value) {
        this.value = value;
    }

    public static Status ofValue(boolean value) {
        return Stream.of(values())
                .filter(status -> status.value == value)
                .findAny()
                .orElse(Status.PASSIVE);
    }

    public boolean getValue() {
        return value;
    }
}
