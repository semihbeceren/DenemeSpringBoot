package com.semihbeceren.scrabble.util;

import com.semihbeceren.scrabble.entity.Action;
import com.semihbeceren.scrabble.entity.Letter;
import com.semihbeceren.scrabble.model.Coordinate;
import com.semihbeceren.scrabble.model.Move;
import com.semihbeceren.scrabble.model.Orientation;

import java.util.*;

public class WordProcessUtil {
    public static List<Letter> wordToLetter(Action action, String word, Coordinate coordinate, Orientation orientation) {
        List<Letter> letters = new ArrayList<>();

        int[] coordinates = {coordinate.getX(), coordinate.getY()};

        word.toUpperCase(new Locale("tr", "TR")).chars().forEach(value -> {
            Letter letter = new Letter(coordinates[0], coordinates[1], Character.toString((char) value), action);
            letters.add(letter);

            if(Orientation.HORIZONTAL.equals(orientation)) coordinates[0]++; else coordinates[1]++;
        });

        return letters;
    }

    public static List<List<Letter>> wordToLetter(Action action, List<Move> moves) {
        List<List<Letter>> letters = new ArrayList<>(moves.size());
        moves.forEach(move -> letters.add(wordToLetter(action, move.getWord(), move.getCoordinate(), move.getOrientation())));
        return letters;
    }
}
