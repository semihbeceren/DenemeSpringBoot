package com.semihbeceren.scrabble.repository.impl;

import com.semihbeceren.scrabble.entity.BaseEntity;
import com.semihbeceren.scrabble.repository.BaseRepository;

import java.lang.reflect.ParameterizedType;
import javax.persistence.*;
import javax.transaction.Transactional;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

public abstract class BaseRepositoryImpl<T extends BaseEntity> implements BaseRepository<T> {
    @PersistenceContext
    protected EntityManager entityManager;

    private final Class<T> clazz;

    BaseRepositoryImpl()
    {
        this.clazz = (Class<T>) ((ParameterizedType) this.getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }

    @Override
    public Optional<T> findById(Long id) {
        return Optional.of(entityManager.find(clazz, id));
    }

    @Transactional
    @Override
    public T save(T entity) {
        if(null == entity.getId()) {
            entity.setCreatedAt(Calendar.getInstance().getTime());
            entityManager.persist(entity);
        }
        else {
            entity.setUpdatedAt(Calendar.getInstance().getTime());
            entityManager.merge(entity);
        }

        return entity;
    }

    @Transactional
    @Override
    public List<T> saveBulk(List<T> entities) {
        entities.forEach(entity -> {
            if(null == entity.getId()) {
                entity.setCreatedAt(Calendar.getInstance().getTime());
                entityManager.persist(entity);
            }
            else {
                entity.setUpdatedAt(Calendar.getInstance().getTime());
                entityManager.merge(entity);
            }
        });

        return entities;
    }

    protected List<T> getResultList(String queryName, List<String> aliases, Object... params)
    {
        Query query = createQueryWithParams(queryName, aliases, params);
        return query.getResultList();
    }

    protected <U> U getSingleGenericResult(String queryName, List<String> aliases, Object... params)
    {
        try
        {
            Query query = createQueryWithParams(queryName, aliases, params);
            query.setMaxResults(1);
            return (U) query.getSingleResult();
        }
        catch (NoResultException e)
        {
            return null;
        }
    }

    private Query createQueryWithParams(String queryName, List<String> aliases, Object... params)
    {
        Query query = entityManager.createNamedQuery(queryName);
        if (params != null)
        {
            IntStream.range(1, params.length + 1).forEach(index -> query.setParameter(aliases.get(index - 1), params[index - 1]));
        }
        return query;
    }
}
