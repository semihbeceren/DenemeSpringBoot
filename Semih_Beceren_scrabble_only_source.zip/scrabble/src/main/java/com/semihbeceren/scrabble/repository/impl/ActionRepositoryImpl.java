package com.semihbeceren.scrabble.repository.impl;

import com.semihbeceren.scrabble.entity.Action;
import com.semihbeceren.scrabble.repository.ActionRepository;
import org.springframework.stereotype.Repository;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Repository("actionRepository")
public class ActionRepositoryImpl extends BaseRepositoryImpl<Action> implements ActionRepository {

    @Override
    public List<Action> findActionsByBoardIdOrderByCreatedAtAsc(Long boardId) {
        return getResultList("findActionsByBoardIdOrderByCreatedAtAsc", Collections.singletonList("boardId"), boardId);
    }

    @Override
    public List<Action> findActionsByBoardIdAndSequenceOrderByCreatedAtAsc(Long boardId, Integer sequence) {
        return getResultList("findActionsByBoardIdAndSequenceOrderByCreatedAtAsc", Arrays.asList("boardId", "sequence"), boardId, sequence);
    }

    @Override
    public Integer findMaxSequenceByBoardId(Long boardId) {
        Integer maxSequence = getSingleGenericResult("findMaxSequenceByBoardId", Collections.singletonList("boardId"), boardId);
        if(null == maxSequence)
            return 0;
        else
            return maxSequence;
    }
}
