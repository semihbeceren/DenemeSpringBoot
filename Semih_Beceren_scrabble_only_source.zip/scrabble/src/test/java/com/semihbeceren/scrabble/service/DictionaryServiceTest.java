package com.semihbeceren.scrabble.service;

import com.semihbeceren.scrabble.BaseTest;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.Assert.*;

public class DictionaryServiceTest extends BaseTest {

    @Autowired
    private DictionaryService dictionaryService;

    @Test
    public void testIsWordValid() {
        assertTrue(dictionaryService.isWordValid("İKLİM"));
        assertFalse(dictionaryService.isWordValid("ABCD"));
    }
}
