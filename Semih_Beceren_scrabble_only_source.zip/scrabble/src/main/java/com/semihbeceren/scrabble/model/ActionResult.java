package com.semihbeceren.scrabble.model;

public class ActionResult {
    private Long boardId;
    private Move move;
    private Integer award;
    private Integer sequence;

    public ActionResult() {
    }

    public ActionResult(Long boardId, Move move, Integer award, Integer sequence) {
        this.boardId = boardId;
        this.move = move;
        this.award = award;
        this.sequence = sequence;
    }

    public Long getBoardId() {
        return boardId;
    }

    public void setBoardId(Long boardId) {
        this.boardId = boardId;
    }

    public Move getMove() {
        return move;
    }

    public void setMove(Move move) {
        this.move = move;
    }

    public Integer getAward() {
        return award;
    }

    public void setAward(Integer award) {
        this.award = award;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

}
