package com.semihbeceren.scrabble.model;

public class Move {
    private Coordinate coordinate;
    private Orientation orientation;
    private String word;

    public Move() {
    }

    public Move(Coordinate coordinate, Orientation orientation, String word) {
        this.coordinate = coordinate;
        this.orientation = orientation;
        this.word = word;
    }

    public Coordinate getCoordinate() {
        return coordinate;
    }

    public void setCoordinate(Coordinate coordinate) {
        this.coordinate = coordinate;
    }

    public Orientation getOrientation() {
        return orientation;
    }

    public void setOrientation(Orientation orientation) {
        this.orientation = orientation;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }
}
