package com.semihbeceren.scrabble.service;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

@Service
public class DictionaryService {

    private static final Set<String> WORD_SET = new HashSet<>(100000);

    @PostConstruct
    public void init() throws IOException {
        Files.lines(new ClassPathResource("scrabble_turkish_dictionary.txt").getFile().toPath())
                .forEach(line -> WORD_SET.add(line.toUpperCase(new Locale("tr", "TR"))));
    }

    public boolean isWordValid(String word) {
        return WORD_SET.contains(word);
    }

}
