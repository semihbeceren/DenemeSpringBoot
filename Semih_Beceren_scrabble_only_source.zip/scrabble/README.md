#scrabble rest api
This project was developed by Semih Beceren for sahibinden.com

###This project uses

- java8 - language
- spring mvc - web framework
- hibernate,jpa - orm
- h2 - database
- aspectj,slf4j over log4j - logging
- swagger2 - docs
- embedded jetty - web server
- junit,hamcrest,spring-test - test

###Package fat-jar from source code
Go to project root folder and execute mvn clean package
jar file will be located on target/scrabble-1.0-SNAPSHOT.jar

###Start Project
java -jar scrabble-1.0-SNAPSHOT.jar

Default port is 8080, if you want to change app port, you can pass port with parameter

java -jar scrabble-1.0-SNAPSHOT.jar port=9091

###Rest Api Docs
I use swagger for rest docs link:

http://localhost:8080/swagger-ui.html

swagger docs: https://swagger.io/

###Request-Response Log
I use AOP for Request-Response Logging. It prints console via log4j with json format